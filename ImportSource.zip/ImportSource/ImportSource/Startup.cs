﻿using ImportSource.Business.capterra;
using ImportSource.Business.softwareadvice;
using ImportSource.BusinessLogic.products;
using ImportSource.DataAccessLayer.capterra;
using ImportSource.DataAccessLayer.products;
using ImportSource.DataAccessLayer.softwareadvice;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource
{
    public class Startup
    {
        public static IServiceProvider ConfigureServices()
        {
            var services = new ServiceCollection();
            services.AddTransient<IProductImporter, ProductImporter>();
            services.AddTransient<ICapterraProductImporter, CapterraProductImporter>();
            services.AddTransient<ISoftwareAdviceProductImporter, SoftwareAdviceProductImporter>();
            services.AddTransient<IGetProductImporter, GetProductImporter>();
            services.AddTransient<IGetCapterraProductImporter, GetCapterraProductImporter>();
            services.AddTransient<IGetSoftwareAdviceProductImporter, GetSoftwareAdviceProductImporter>();
            services.AddSingleton<Program>();

            return services.BuildServiceProvider();
        }
    }
}
