﻿using CommandLine;
using ImportSource;
using ImportSource.BusinessLogic.products;
using ImportSource.Model;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

public class Program
{
        private readonly IProductImporter _productImporter;
        public Program(IProductImporter productImporter)
        {
            _productImporter = productImporter;
        }
    public static void Main(string[] args)
    {
        var serviceProvider = Startup.ConfigureServices();
        var program = serviceProvider.GetRequiredService<Program>();       
        Parser.Default.ParseArguments<Options>(args)
                .WithParsed(options =>
                {
                    program.ImportProducts(options.Source, options.FilePath);

                })
                .WithNotParsed(errors =>
                {
                    Console.WriteLine("Invalid Command");
                });
        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();

    }

    public void ImportProducts(string source, string filePath)
    {
        _productImporter.ImportProducts(source, filePath);
    }

    internal void ImportCapterraProducts(string v)
    {
        throw new NotImplementedException();
    }
}
