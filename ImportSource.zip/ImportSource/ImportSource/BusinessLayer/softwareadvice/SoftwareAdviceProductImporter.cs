﻿using ImportSource.DataAccessLayer.softwareadvice;
using ImportSource.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.Business.softwareadvice
{
    public class SoftwareAdviceProductImporter : ISoftwareAdviceProductImporter
    {
        private IGetSoftwareAdviceProductImporter _getSoftwareAdviceProductImporter;

        public SoftwareAdviceProductImporter(IGetSoftwareAdviceProductImporter getSoftwareAdviceProductImporter)
        {
            _getSoftwareAdviceProductImporter = getSoftwareAdviceProductImporter;
        }
        public void ImportSoftwareAdviceProducts(string filePath)
        {
            _getSoftwareAdviceProductImporter.ImportSoftwareAdviceProducts(filePath);
        }
    }
}
