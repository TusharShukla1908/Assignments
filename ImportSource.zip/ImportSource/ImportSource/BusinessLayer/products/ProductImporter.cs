﻿using ImportSource.Business.capterra;
using ImportSource.Business.softwareadvice;
using ImportSource.DataAccessLayer.products;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.BusinessLogic.products
{
    public class ProductImporter : IProductImporter
    {
        public IGetProductImporter _getProductImporter;
        public ProductImporter(
            ICapterraProductImporter capterraProductImporter,
            ISoftwareAdviceProductImporter softwareAdviceProductImporter,
            IGetProductImporter getProductImporter) 
        {
            _getProductImporter = getProductImporter;
        }
        public void ImportProducts(string source, string filePath)
        {
           _getProductImporter.ImportProducts(source, filePath);
        }
    }
}
