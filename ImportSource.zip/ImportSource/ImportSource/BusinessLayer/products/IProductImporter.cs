﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.BusinessLogic.products
{
    public interface IProductImporter
    {
        void ImportProducts(string source, string filePath);
    }
}
