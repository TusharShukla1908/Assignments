﻿using ImportSource.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YamlDotNet.Serialization.NamingConventions;
using YamlDotNet.Serialization;
using ImportSource.DataAccessLayer.capterra;

namespace ImportSource.Business.capterra
{
    public class CapterraProductImporter : ICapterraProductImporter
    {
        private IGetCapterraProductImporter _getCapterraProductImporter;
        public CapterraProductImporter(IGetCapterraProductImporter getCapterraProductImporter)
        {
            _getCapterraProductImporter = getCapterraProductImporter;

        }
        public void ImportCapterraProducts(string filePath)
        {
            _getCapterraProductImporter.ImportCapterraProducts(filePath);
        }
    }
}
