﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.DataAccessLayer.products
{
    public interface IGetProductImporter
    {
        void ImportProducts(string source, string filePath);
    }
}
