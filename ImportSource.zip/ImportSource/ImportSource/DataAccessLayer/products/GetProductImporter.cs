﻿using ImportSource.DataAccessLayer.capterra;
using ImportSource.DataAccessLayer.softwareadvice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.DataAccessLayer.products
{
    public class GetProductImporter : IGetProductImporter
    {
        private IGetCapterraProductImporter _getCapterraProductImporter;
        private IGetSoftwareAdviceProductImporter _getSoftwareAdviceProductImporter;
        public GetProductImporter(
            IGetCapterraProductImporter getCapterraProductImporter,
            IGetSoftwareAdviceProductImporter getSoftwareAdviceProductImporter)
        {
            _getCapterraProductImporter = getCapterraProductImporter;
            _getSoftwareAdviceProductImporter = getSoftwareAdviceProductImporter;
        }
        public void ImportProducts(string source, string filePath)
        {
            if (source.Contains("capterra"))
            {
                _getCapterraProductImporter.ImportCapterraProducts(filePath);
            }
            else if (source.Contains("softwareadvice"))
            {
                _getSoftwareAdviceProductImporter.ImportSoftwareAdviceProducts(filePath);
            }
            else
            {
                Console.WriteLine("Invalid source specified.");
            }
        }
    }
}
