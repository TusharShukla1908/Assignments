﻿using ImportSource.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YamlDotNet.Serialization.NamingConventions;
using YamlDotNet.Serialization;

namespace ImportSource.DataAccessLayer.capterra
{
    public class GetCapterraProductImporter : IGetCapterraProductImporter
    {
        public void ImportCapterraProducts(string filePath)
        {
            const string AllowedFileType = "yaml";
            var filedetails = filePath.Split(".");
            var fileType = filedetails.Last();
            if (fileType.ToLower() == AllowedFileType)
            {
                var deserializer = new DeserializerBuilder().WithNamingConvention(CamelCaseNamingConvention.Instance).Build();
                var content = File.ReadAllText(filePath);
                var products = deserializer.Deserialize<Product[]>(content);

                foreach (var product in products)
                {
                    Console.WriteLine($"importing: Name: \"{product.Name}\"; Categories: {string.Join(", ", product.Tags)}; Twitter: @{product.Twitter}");

                }
            }
            else
            {
                Console.WriteLine("Invalid file type");
            }
        }
    }
}
