﻿using ImportSource.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.DataAccessLayer.softwareadvice
{
    public class GetSoftwareAdviceProductImporter : IGetSoftwareAdviceProductImporter
    {
        public void ImportSoftwareAdviceProducts(string filePath)
        {
            var content = File.ReadAllText(filePath);
            var products = JsonConvert.DeserializeObject<SoftwareAdviceProducts>(content);

            foreach (var product in products.Products)
            {
                Console.WriteLine($"importing: Title: \"{product.Title}\"; Categories: {string.Join(", ", product.Categories)}; Twitter: {product.Twitter}");
            }
        }
    }
}
