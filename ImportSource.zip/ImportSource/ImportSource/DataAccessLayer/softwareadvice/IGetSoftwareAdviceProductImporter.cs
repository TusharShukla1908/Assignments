﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.DataAccessLayer.softwareadvice
{
    public interface IGetSoftwareAdviceProductImporter
    {
        void ImportSoftwareAdviceProducts(string filePath);
    }
}
