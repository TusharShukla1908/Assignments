﻿using ImportSource.BusinessLogic.products;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportSource.Tests
{

    [TestFixture]
    public class ProgramTests
    {
        [Test]
        public void ImportProducts_ValidArguments_CallsProductImporter()
        {
            var productImporterMock = new Mock<IProductImporter>();
            var program = new Program(productImporterMock.Object);

            program.ImportProducts("capterra", "feed-products/capterra.yaml");

            productImporterMock.Verify(p => p.ImportProducts("capterra", "feed-products/capterra.yaml"), Times.Once());
        }
    }
}
